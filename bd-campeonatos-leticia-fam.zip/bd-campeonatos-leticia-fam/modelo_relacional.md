# Modelo Relacional — Gestão de Campeonatos Desportivos Comunitários

**Autora:** Letícia Figueira Fam
**Notação:** <u>chave primária</u> sublinhada · `#` = chave estrangeira (FK)

## 1. Tabelas, chaves primárias e chaves estrangeiras

| Tabela | Atributos |
|---|---|
| **Utilizador** | <u>id_utilizador</u>, nome, email (único), palavra_passe, perfil, data_registo |
| **Treinador** | <u>id_treinador</u>, nome, telefone, nivel_formacao, anos_experiencia |
| **Arbitro** | <u>id_arbitro</u>, nome, telefone, categoria, anos_experiencia |
| **Equipa** | <u>id_equipa</u>, nome (único), bairro, data_fundacao, cor_camisola, #id_treinador |
| **Jogador** | <u>id_jogador</u>, nome, data_nascimento, posicao, numero_camisola, #id_equipa — único (id_equipa, numero_camisola) |
| **Competicao** | <u>id_competicao</u>, nome (único), modalidade, categoria, epoca, data_inicio, data_fim, estado, #id_organizador |
| **Inscricao** | <u>#id_competicao</u>, <u>#id_equipa</u>, data_inscricao |
| **Jornada** *(entidade fraca)* | <u>#id_competicao</u>, <u>numero_jornada</u>, data_jornada, descricao |
| **Jogo** | <u>id_jogo</u>, #id_competicao, #numero_jornada, #id_equipa_casa, #id_equipa_fora, #id_arbitro, data_hora, local_jogo, estado |
| **Resultado** | <u>id_resultado</u>, #id_jogo (único), golos_casa, golos_fora, data_registo, observacoes |

## 2. Chaves estrangeiras

| Tabela.coluna(s) | Referencia | Significado |
|---|---|---|
| Equipa.id_treinador | Treinador.id_treinador | Cada equipa tem um treinador |
| Jogador.id_equipa | Equipa.id_equipa | Cada jogador pertence a uma equipa |
| Competicao.id_organizador | Utilizador.id_utilizador | Utilizador que organiza a competição |
| Inscricao.id_competicao | Competicao.id_competicao | Competição em que a equipa participa |
| Inscricao.id_equipa | Equipa.id_equipa | Equipa inscrita |
| Jornada.id_competicao | Competicao.id_competicao | Competição a que a jornada pertence (identificadora) |
| Jogo.(id_competicao, numero_jornada) | Jornada.(id_competicao, numero_jornada) | Jornada em que o jogo se realiza (FK composta) |
| Jogo.(id_competicao, id_equipa_casa) | Inscricao.(id_competicao, id_equipa) | A equipa da casa tem de estar inscrita na competição (FK composta) |
| Jogo.(id_competicao, id_equipa_fora) | Inscricao.(id_competicao, id_equipa) | A equipa visitante tem de estar inscrita na competição (FK composta) |
| Jogo.id_arbitro | Arbitro.id_arbitro | Árbitro do jogo |
| Resultado.id_jogo | Jogo.id_jogo | Jogo a que o resultado pertence |

## 3. Regras usadas na conversão ER → relacional

1. **Cada entidade forte** passou a uma tabela com a sua chave primária.
2. **Entidade fraca (Jornada):** a chave primária é composta — herda a chave da entidade forte `Competicao` (`id_competicao`) e junta a chave parcial `numero_jornada`. Se a competição for eliminada, as suas jornadas deixam de ter razão de existir (dependência de existência).
3. **Relacionamentos 1:N** (Treinador–Equipa, Equipa–Jogador, Utilizador–Competicao, Arbitro–Jogo, Jornada–Jogo): a chave primária do lado «1» foi colocada como chave estrangeira no lado «N».
4. **Relacionamento N:M** (Equipa–Competicao): originou a tabela associativa **Inscricao**, com chave primária composta pelas duas chaves estrangeiras e o atributo próprio `data_inscricao`.
5. **Relacionamentos Equipa–Jogo (casa e visitante):** duas chaves estrangeiras em `Jogo`. Para garantir que ambas as equipas estão inscritas na competição do jogo, estas chaves são **compostas** e apontam para `Inscricao`.
6. **Relacionamento 1:1** (Jogo–Resultado): a chave de `Jogo` foi colocada em `Resultado` com restrição `UNIQUE`, e a participação de `Resultado` é total (não existe resultado sem jogo).
7. **Classificação:** não é uma tabela (seria informação redundante). É calculada pela vista `vw_classificacao` a partir dos resultados: vitória = 3 pontos, empate = 1, derrota = 0.

## 4. Cardinalidade e participação

| Relacionamento | Cardinalidade | Participação |
|---|---|---|
| Treinador **treina** Equipa | 1 : N | Treinador parcial · Equipa total |
| Equipa **tem plantel** Jogador | 1 : N | Equipa parcial · Jogador total |
| Equipa **inscreve-se** em Competicao | N : M | Ambas parciais |
| Utilizador **organiza** Competicao | 1 : N | Utilizador parcial · Competicao total |
| Competicao **é composta por** Jornada (identificador) | 1 : N | Competicao parcial · Jornada total |
| Jornada **integra** Jogo | 1 : N | Jornada parcial · Jogo total |
| Equipa **joga em casa** Jogo | 1 : N | Equipa parcial · Jogo total |
| Equipa **joga como visitante** Jogo | 1 : N | Equipa parcial · Jogo total |
| Arbitro **arbitra** Jogo | 1 : N | Arbitro parcial · Jogo total |
| Jogo **produz** Resultado | 1 : 1 | Jogo parcial (ainda não realizado) · Resultado total |

## 5. Restrições principais (implementadas no script)

- Domínios com `CHECK`: perfil do utilizador, nível de formação, categoria do árbitro, estado da competição (`Planeada`, `Em curso`, `Concluída`) e estado do jogo (`Agendado`, `Realizado`, `Adiado`).
- `data_fim >= data_inicio` na competição; `golos_casa >= 0` e `golos_fora >= 0`; `id_equipa_casa <> id_equipa_fora`.
- `UNIQUE`: email do utilizador, nome da equipa, nome da competição, número de camisola dentro da equipa, confronto (competição, casa, fora) e `Resultado.id_jogo`.
