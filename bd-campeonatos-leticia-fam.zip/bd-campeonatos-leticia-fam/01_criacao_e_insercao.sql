-- =====================================================================
-- Projeto de Base de Dados — Sistema de Gestão de Campeonatos Desportivos Comunitários
-- Autora: Letícia Figueira Fam
-- Disciplina: Tecnologias de Base de Dados (2.º ano, Licenciatura em Informática)
-- SGBD: MySQL 8.0.16 ou superior (necessário para as restrições CHECK)
-- Ficheiro: 01_criacao_e_insercao.sql
-- Conteúdo: criação da base de dados, tabelas, inserção de registos e vista de classificação.
-- Pode ser executado de raiz, sem erros (recria a base de dados de cada vez).
-- =====================================================================

DROP DATABASE IF EXISTS campeonatos_comunitarios;
CREATE DATABASE campeonatos_comunitarios CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campeonatos_comunitarios;

-- =====================================================================
-- PARTE 1 — CRIAÇÃO DAS TABELAS (ordem imposta pelas chaves estrangeiras)
-- =====================================================================

-- Utilizadores do futuro sistema web (login e perfis de acesso)
CREATE TABLE Utilizador (
  id_utilizador  INT AUTO_INCREMENT PRIMARY KEY,
  nome           VARCHAR(100) NOT NULL,
  email          VARCHAR(120) NOT NULL UNIQUE,
  palavra_passe  CHAR(64)     NOT NULL,            -- hash SHA-256 (nunca texto simples)
  perfil         VARCHAR(20)  NOT NULL DEFAULT 'Adepto',
  data_registo   DATE         NOT NULL,
  CONSTRAINT ck_utilizador_perfil CHECK (perfil IN ('Administrador','Organizador','Treinador','Arbitro','Adepto'))
);

CREATE TABLE Treinador (
  id_treinador     INT AUTO_INCREMENT PRIMARY KEY,
  nome             VARCHAR(100) NOT NULL,
  telefone         VARCHAR(20),
  nivel_formacao   VARCHAR(20)  NOT NULL DEFAULT 'Sem formação',
  anos_experiencia INT          NOT NULL DEFAULT 0,
  CONSTRAINT ck_treinador_nivel CHECK (nivel_formacao IN ('Sem formação','Nível I','Nível II','Nível III')),
  CONSTRAINT ck_treinador_anos  CHECK (anos_experiencia >= 0)
);

CREATE TABLE Arbitro (
  id_arbitro       INT AUTO_INCREMENT PRIMARY KEY,
  nome             VARCHAR(100) NOT NULL,
  telefone         VARCHAR(20),
  categoria        VARCHAR(20)  NOT NULL DEFAULT 'Comunitário',
  anos_experiencia INT          NOT NULL DEFAULT 0,
  CONSTRAINT ck_arbitro_categoria CHECK (categoria IN ('Comunitário','Distrital','Provincial')),
  CONSTRAINT ck_arbitro_anos      CHECK (anos_experiencia >= 0)
);

CREATE TABLE Equipa (
  id_equipa       INT AUTO_INCREMENT PRIMARY KEY,
  nome            VARCHAR(80)  NOT NULL UNIQUE,
  bairro          VARCHAR(60)  NOT NULL,
  data_fundacao   DATE,
  cor_camisola    VARCHAR(20),
  id_treinador    INT          NOT NULL,
  CONSTRAINT fk_equipa_treinador FOREIGN KEY (id_treinador) REFERENCES Treinador (id_treinador)
);

CREATE TABLE Jogador (
  id_jogador       INT AUTO_INCREMENT PRIMARY KEY,
  nome             VARCHAR(100) NOT NULL,
  data_nascimento  DATE         NOT NULL,
  posicao          VARCHAR(30)  NOT NULL,
  numero_camisola  INT          NOT NULL,
  id_equipa        INT          NOT NULL,
  CONSTRAINT fk_jogador_equipa FOREIGN KEY (id_equipa) REFERENCES Equipa (id_equipa),
  CONSTRAINT uq_jogador_numero UNIQUE (id_equipa, numero_camisola),   -- número único dentro da equipa
  CONSTRAINT ck_jogador_numero CHECK (numero_camisola BETWEEN 0 AND 99)
);

CREATE TABLE Competicao (
  id_competicao    INT AUTO_INCREMENT PRIMARY KEY,
  nome             VARCHAR(100) NOT NULL UNIQUE,
  modalidade       VARCHAR(30)  NOT NULL,
  categoria        VARCHAR(20)  NOT NULL,
  epoca            VARCHAR(9)   NOT NULL,
  data_inicio      DATE         NOT NULL,
  data_fim         DATE         NOT NULL,
  estado           VARCHAR(15)  NOT NULL DEFAULT 'Planeada',
  id_organizador   INT          NOT NULL,
  CONSTRAINT fk_competicao_organizador FOREIGN KEY (id_organizador) REFERENCES Utilizador (id_utilizador),
  CONSTRAINT ck_competicao_estado CHECK (estado IN ('Planeada','Em curso','Concluída')),
  CONSTRAINT ck_competicao_datas  CHECK (data_fim >= data_inicio)
);

-- Relação N:M entre Equipa e Competicao (tabela associativa)
CREATE TABLE Inscricao (
  id_competicao    INT  NOT NULL,
  id_equipa        INT  NOT NULL,
  data_inscricao   DATE NOT NULL,
  PRIMARY KEY (id_competicao, id_equipa),
  CONSTRAINT fk_inscricao_competicao FOREIGN KEY (id_competicao) REFERENCES Competicao (id_competicao),
  CONSTRAINT fk_inscricao_equipa     FOREIGN KEY (id_equipa)     REFERENCES Equipa (id_equipa)
);

-- ENTIDADE FRACA: a Jornada só existe dentro de uma Competicao.
-- Chave primária composta = chave da entidade forte + número parcial da jornada.
CREATE TABLE Jornada (
  id_competicao    INT         NOT NULL,
  numero_jornada   INT         NOT NULL,
  data_jornada     DATE        NOT NULL,
  descricao        VARCHAR(40),
  PRIMARY KEY (id_competicao, numero_jornada),
  CONSTRAINT fk_jornada_competicao FOREIGN KEY (id_competicao) REFERENCES Competicao (id_competicao),
  CONSTRAINT ck_jornada_numero CHECK (numero_jornada > 0)
);

-- O jogo pertence a uma jornada e as duas equipas têm de estar inscritas na mesma competição
-- (chaves estrangeiras compostas para Jornada e para Inscricao).
CREATE TABLE Jogo (
  id_jogo          INT AUTO_INCREMENT PRIMARY KEY,
  id_competicao    INT          NOT NULL,
  numero_jornada   INT          NOT NULL,
  id_equipa_casa   INT          NOT NULL,
  id_equipa_fora   INT          NOT NULL,
  id_arbitro       INT          NOT NULL,
  data_hora        DATETIME     NOT NULL,
  local_jogo       VARCHAR(100) NOT NULL,
  estado           VARCHAR(15)  NOT NULL DEFAULT 'Agendado',
  CONSTRAINT fk_jogo_jornada FOREIGN KEY (id_competicao, numero_jornada) REFERENCES Jornada (id_competicao, numero_jornada),
  CONSTRAINT fk_jogo_casa    FOREIGN KEY (id_competicao, id_equipa_casa) REFERENCES Inscricao (id_competicao, id_equipa),
  CONSTRAINT fk_jogo_fora    FOREIGN KEY (id_competicao, id_equipa_fora) REFERENCES Inscricao (id_competicao, id_equipa),
  CONSTRAINT fk_jogo_arbitro FOREIGN KEY (id_arbitro) REFERENCES Arbitro (id_arbitro),
  CONSTRAINT uq_jogo_confronto UNIQUE (id_competicao, id_equipa_casa, id_equipa_fora),
  CONSTRAINT ck_jogo_equipas CHECK (id_equipa_casa <> id_equipa_fora),
  CONSTRAINT ck_jogo_estado  CHECK (estado IN ('Agendado','Realizado','Adiado'))
);

-- golos_casa / golos_fora = golos (futebol, futsal) ou pontos (basquetebol, etc.)
CREATE TABLE Resultado (
  id_resultado     INT AUTO_INCREMENT PRIMARY KEY,
  id_jogo          INT          NOT NULL UNIQUE,     -- UNIQUE => relação 1:1 com Jogo
  golos_casa       INT          NOT NULL,
  golos_fora       INT          NOT NULL,
  data_registo     DATETIME     NOT NULL,
  observacoes      VARCHAR(200),
  CONSTRAINT fk_resultado_jogo FOREIGN KEY (id_jogo) REFERENCES Jogo (id_jogo),
  CONSTRAINT ck_resultado_golos CHECK (golos_casa >= 0 AND golos_fora >= 0)
);

-- =====================================================================
-- PARTE 2 — INSERÇÃO DOS REGISTOS (ordem: tabelas independentes primeiro)
-- =====================================================================

-- 2.1 Utilizador (20 registos)
INSERT INTO Utilizador (id_utilizador, nome, email, palavra_passe, perfil, data_registo) VALUES
  (1, 'Amélia Nhangumele', 'amelia.nhangumele@exemplo.co.mz', SHA2('Demo@2026-01', 256), 'Administrador', '2026-08-01'),
  (2, 'Bernardo Macuvele', 'bernardo.macuvele@exemplo.co.mz', SHA2('Demo@2026-02', 256), 'Administrador', '2026-08-02'),
  (3, 'Cíntia Manave', 'cintia.manave@exemplo.co.mz', SHA2('Demo@2026-03', 256), 'Organizador', '2026-08-03'),
  (4, 'Danilo Nhamitambo', 'danilo.nhamitambo@exemplo.co.mz', SHA2('Demo@2026-04', 256), 'Organizador', '2026-08-04'),
  (5, 'Eugénia Bila', 'eugenia.bila@exemplo.co.mz', SHA2('Demo@2026-05', 256), 'Organizador', '2026-08-05'),
  (6, 'Fernando Zucula', 'fernando.zucula@exemplo.co.mz', SHA2('Demo@2026-06', 256), 'Organizador', '2026-08-06'),
  (7, 'Graça Mutisse', 'graca.mutisse@exemplo.co.mz', SHA2('Demo@2026-07', 256), 'Organizador', '2026-08-07'),
  (8, 'Hilário Mucambe', 'hilario.mucambe@exemplo.co.mz', SHA2('Demo@2026-08', 256), 'Organizador', '2026-08-08'),
  (9, 'Ismael Tembe', 'ismael.tembe@exemplo.co.mz', SHA2('Demo@2026-09', 256), 'Treinador', '2026-08-09'),
  (10, 'Jussara Cumbi', 'jussara.cumbi@exemplo.co.mz', SHA2('Demo@2026-10', 256), 'Treinador', '2026-08-10'),
  (11, 'Kassim Abdul', 'kassim.abdul@exemplo.co.mz', SHA2('Demo@2026-11', 256), 'Treinador', '2026-08-11'),
  (12, 'Lúcia Nhachungue', 'lucia.nhachungue@exemplo.co.mz', SHA2('Demo@2026-12', 256), 'Treinador', '2026-08-12'),
  (13, 'Mussá Ibraimo', 'mussa.ibraimo@exemplo.co.mz', SHA2('Demo@2026-13', 256), 'Arbitro', '2026-08-13'),
  (14, 'Naíma Selemane', 'naima.selemane@exemplo.co.mz', SHA2('Demo@2026-14', 256), 'Arbitro', '2026-08-14'),
  (15, 'Orlando Machado', 'orlando.machado@exemplo.co.mz', SHA2('Demo@2026-15', 256), 'Arbitro', '2026-08-15'),
  (16, 'Palmira Gove', 'palmira.gove@exemplo.co.mz', SHA2('Demo@2026-16', 256), 'Arbitro', '2026-08-16'),
  (17, 'Quintino Mavie', 'quintino.mavie@exemplo.co.mz', SHA2('Demo@2026-17', 256), 'Adepto', '2026-08-17'),
  (18, 'Rita Mutola', 'rita.mutola@exemplo.co.mz', SHA2('Demo@2026-18', 256), 'Adepto', '2026-08-18'),
  (19, 'Samuel Cuamba', 'samuel.cuamba@exemplo.co.mz', SHA2('Demo@2026-19', 256), 'Adepto', '2026-08-19'),
  (20, 'Tânia Macuácua', 'tania.macuacua@exemplo.co.mz', SHA2('Demo@2026-20', 256), 'Adepto', '2026-08-20');

-- 2.2 Treinador (20 registos)
INSERT INTO Treinador (id_treinador, nome, telefone, nivel_formacao, anos_experiencia) VALUES
  (1, 'Armando Tivane', '+258 83 137 1173', 'Nível I', 2),
  (2, 'Celeste Macuácua', '+258 84 174 1346', 'Nível II', 5),
  (3, 'Domingos Nhaca', '+258 85 211 1519', 'Sem formação', 8),
  (4, 'Fátima Sitoe', '+258 86 248 1692', 'Nível III', 11),
  (5, 'Gilberto Mabunda', '+258 87 285 1865', 'Nível I', 14),
  (6, 'Helena Bila', '+258 82 322 2038', 'Nível I', 3),
  (7, 'Isidro Cossa', '+258 83 359 2211', 'Nível II', 6),
  (8, 'Joana Matavele', '+258 84 396 2384', 'Sem formação', 9),
  (9, 'Lourenço Mucavele', '+258 85 433 2557', 'Nível III', 12),
  (10, 'Marta Zimba', '+258 86 470 2730', 'Nível I', 15),
  (11, 'Nelson Guambe', '+258 87 507 2903', 'Nível I', 4),
  (12, 'Olívia Chongo', '+258 82 544 3076', 'Nível II', 7),
  (13, 'Paulo Langa', '+258 83 581 3249', 'Sem formação', 10),
  (14, 'Quitéria Massingue', '+258 84 618 3422', 'Nível III', 13),
  (15, 'Rui Machava', '+258 85 655 3595', 'Nível I', 2),
  (16, 'Salomé Muianga', '+258 86 692 3768', 'Nível I', 5),
  (17, 'Tomás Cumbe', '+258 87 729 3941', 'Nível II', 8),
  (18, 'Vânia Uamusse', '+258 82 766 4114', 'Sem formação', 11),
  (19, 'Xavier Nhantumbo', '+258 83 803 4287', 'Nível III', 14),
  (20, 'Zélia Chilaule', '+258 84 840 4460', 'Nível I', 3);

-- 2.3 Arbitro (20 registos)
INSERT INTO Arbitro (id_arbitro, nome, telefone, categoria, anos_experiencia) VALUES
  (1, 'Albino Chaúque', '+258 84 150 9650', 'Comunitário', 1),
  (2, 'Beatriz Nhancale', '+258 85 187 9823', 'Distrital', 8),
  (3, 'Casimiro Tseco', '+258 86 224 9996', 'Provincial', 15),
  (4, 'Dalila Mbanze', '+258 87 261 1169', 'Comunitário', 7),
  (5, 'Elias Cumbana', '+258 82 298 1342', 'Comunitário', 14),
  (6, 'Filipa Mazuze', '+258 83 335 1515', 'Distrital', 6),
  (7, 'Guilherme Xerinda', '+258 84 372 1688', 'Provincial', 13),
  (8, 'Hortênsia Bata', '+258 85 409 1861', 'Comunitário', 5),
  (9, 'Inocêncio Mussá', '+258 86 446 2034', 'Comunitário', 12),
  (10, 'Judite Ubisse', '+258 87 483 2207', 'Distrital', 4),
  (11, 'Lázaro Nhavene', '+258 82 520 2380', 'Provincial', 11),
  (12, 'Mércia Zacarias', '+258 83 557 2553', 'Comunitário', 3),
  (13, 'Narciso Fenhane', '+258 84 594 2726', 'Comunitário', 10),
  (14, 'Odete Maculuve', '+258 85 631 2899', 'Distrital', 2),
  (15, 'Pascoal Mutemba', '+258 86 668 3072', 'Provincial', 9),
  (16, 'Rosa Chivambo', '+258 87 705 3245', 'Comunitário', 1),
  (17, 'Sebastião Mucache', '+258 82 742 3418', 'Comunitário', 8),
  (18, 'Teresa Mathe', '+258 83 779 3591', 'Distrital', 15),
  (19, 'Urbano Sigaúque', '+258 84 816 3764', 'Provincial', 7),
  (20, 'Vera Cuamba', '+258 85 853 3937', 'Comunitário', 14);

-- 2.4 Equipa (20 registos; depende de Treinador)
INSERT INTO Equipa (id_equipa, nome, bairro, data_fundacao, cor_camisola, id_treinador) VALUES
  (1, 'Malhangalene FC', 'Malhangalene', '2012-03-15', 'Azul', 1),
  (2, 'Polana Caniço United', 'Polana Caniço', '2015-06-20', 'Vermelha', 2),
  (3, 'Maxaquene Juniors', 'Maxaquene', '2010-01-10', 'Verde', 3),
  (4, 'Xipamanine Estrela', 'Xipamanine', '2018-09-05', 'Amarela', 4),
  (5, 'Mafalala Stars', 'Mafalala', '2016-02-27', 'Branca', 5),
  (6, 'Chamanculo Sports', 'Chamanculo', '2011-11-12', 'Laranja', 6),
  (7, 'Alto-Maé FC', 'Alto-Maé', '2014-04-18', 'Preta', 7),
  (8, 'Hulene Unidos', 'Hulene', '2017-07-30', 'Roxa', 8),
  (9, 'Laulane Tigres', 'Laulane', '2013-05-09', 'Laranja', 9),
  (10, 'Zimpeto Águias', 'Zimpeto', '2019-08-22', 'Branca', 10),
  (11, 'Magoanine Leões', 'Magoanine', '2015-10-03', 'Amarela', 11),
  (12, 'Albasine Rangers', 'Albasine', '2016-12-14', 'Azul', 12),
  (13, 'ES Laulane', 'Laulane', '2020-02-10', 'Verde', 13),
  (14, 'ES Polana', 'Polana', '2019-02-11', 'Azul', 14),
  (15, 'ES Zimpeto', 'Zimpeto', '2021-02-08', 'Vermelha', 15),
  (16, 'ES Magoanine', 'Magoanine', '2020-02-17', 'Branca', 16),
  (17, 'Costa do Sol Basket', 'Costa do Sol', '2017-05-06', 'Azul', 17),
  (18, 'Sommerschield Hoops', 'Sommerschield', '2018-03-24', 'Preta', 18),
  (19, 'Jardim Basket Club', 'Jardim', '2014-09-13', 'Vermelha', 19),
  (20, 'Matola Gare Dunkers', 'Matola Gare', '2016-08-01', 'Amarela', 20);

-- 2.5 Jogador (40 registos; depende de Equipa)
INSERT INTO Jogador (id_jogador, nome, data_nascimento, posicao, numero_camisola, id_equipa) VALUES
  (1, 'Carlos Matsinhe', '1998-04-12', 'Guarda-Redes', 1, 1),
  (2, 'Eduardo Cuna', '2000-08-30', 'Avançado', 9, 1),
  (3, 'Ernesto Manhiça', '1997-02-19', 'Defesa', 4, 2),
  (4, 'Gaspar Tembe', '1999-11-05', 'Médio', 8, 2),
  (5, 'Hélder Mahumane', '2001-06-21', 'Avançado', 10, 3),
  (6, 'Ivan Chirindza', '1996-09-14', 'Guarda-Redes', 1, 3),
  (7, 'Jaime Bambo', '2000-01-25', 'Defesa', 3, 4),
  (8, 'Kelven Mazive', '2002-03-17', 'Médio', 6, 4),
  (9, 'Leonel Machiana', '1998-12-08', 'Avançado', 11, 5),
  (10, 'Manuel Uqueio', '1995-05-29', 'Guarda-Redes', 12, 5),
  (11, 'Nelito Fumo', '2003-07-11', 'Médio', 5, 6),
  (12, 'Orlando Ngomane', '1999-10-02', 'Defesa', 2, 6),
  (13, 'Pedro Mavie', '2000-04-04', 'Guarda-Redes', 1, 7),
  (14, 'Quim Sambo', '2001-09-16', 'Pivô', 9, 7),
  (15, 'Rafael Tomo', '2002-02-23', 'Ala', 7, 8),
  (16, 'Sérgio Bie', '1999-08-19', 'Fixo', 5, 8),
  (17, 'Telmo Zandamela', '2003-05-30', 'Ala', 8, 9),
  (18, 'Uldino Mate', '2000-11-27', 'Pivô', 10, 9),
  (19, 'Valdemiro Manjate', '1998-06-06', 'Guarda-Redes', 1, 10),
  (20, 'Wilson Macamo', '2004-01-13', 'Fixo', 4, 10),
  (21, 'Xadreque Nhabinde', '2001-03-22', 'Ala', 6, 11),
  (22, 'Yuran Cuambe', '2002-12-01', 'Pivô', 11, 11),
  (23, 'Zeferino Massango', '1999-07-07', 'Fixo', 3, 12),
  (24, 'Abel Nhampossa', '2005-04-28', 'Ala', 7, 12),
  (25, 'Alberto Come', '2009-03-14', 'Guarda-Redes', 1, 13),
  (26, 'Bruna Mavila', '2009-10-09', 'Médio', 8, 13),
  (27, 'Cláudio Matimbe', '2010-01-19', 'Defesa', 4, 14),
  (28, 'Dulce Mbombo', '2009-06-25', 'Avançado', 9, 14),
  (29, 'Edilson Nhaule', '2010-05-15', 'Médio', 6, 15),
  (30, 'Fernanda Tivane', '2009-12-02', 'Defesa', 3, 15),
  (31, 'Gizélio Cossa', '2009-08-18', 'Avançado', 10, 16),
  (32, 'Hermínia Sumbana', '2010-02-07', 'Guarda-Redes', 12, 16),
  (33, 'Inácio Mabote', '2000-09-09', 'Base', 5, 17),
  (34, 'Jordão Chauque', '1997-04-21', 'Poste', 13, 17),
  (35, 'Kátia Macie', '2001-01-30', 'Extremo', 7, 18),
  (36, 'Leandro Cuinica', '1999-05-17', 'Base', 4, 18),
  (37, 'Mário Banze', '1998-10-26', 'Poste', 15, 19),
  (38, 'Nilza Guilundo', '2002-07-03', 'Base', 6, 19),
  (39, 'Osvaldo Tamele', '2000-02-14', 'Extremo', 8, 20),
  (40, 'Patrícia Vilanculos', '2003-11-20', 'Poste', 11, 20);

-- 2.6 Competicao (20 registos; depende de Utilizador)
INSERT INTO Competicao (id_competicao, nome, modalidade, categoria, epoca, data_inicio, data_fim, estado, id_organizador) VALUES
  (1, 'Taça dos Bairros 2026', 'Futebol 11', 'Seniores', '2026', '2026-10-03', '2026-11-07', 'Em curso', 4),
  (2, 'Torneio Inter-Bairros de Futsal 2026', 'Futsal', 'Seniores', '2026', '2026-10-04', '2026-11-08', 'Em curso', 5),
  (3, 'Liga Escolar Sub-17 2026', 'Futebol 11', 'Sub-17', '2026', '2026-10-07', '2026-10-21', 'Em curso', 6),
  (4, 'Copa Basquetebol Comunitário 2026', 'Basquetebol', 'Seniores', '2026', '2026-10-10', '2026-10-31', 'Em curso', 7),
  (5, 'Torneio de Verão de Futebol de Praia', 'Futebol de Praia', 'Seniores', '2026/27', '2026-12-05', '2026-12-20', 'Planeada', 3),
  (6, 'Taça Mulheres em Campo', 'Futebol 11', 'Feminino', '2026/27', '2026-11-14', '2027-01-30', 'Planeada', 8),
  (7, 'Torneio de Futsal Sub-15', 'Futsal', 'Sub-15', '2026/27', '2027-02-06', '2027-03-27', 'Planeada', 4),
  (8, 'Liga Escolar Sub-15 2026', 'Futebol 7', 'Sub-15', '2026/27', '2026-11-04', '2026-12-02', 'Planeada', 5),
  (9, 'Campeonato de Voleibol dos Bairros', 'Voleibol', 'Seniores', '2026/27', '2027-02-13', '2027-04-24', 'Planeada', 6),
  (10, 'Torneio de Andebol Comunitário', 'Andebol', 'Seniores', '2026/27', '2027-03-06', '2027-04-17', 'Planeada', 7),
  (11, 'Taça Veteranos de Maputo', 'Futebol 7', 'Veteranos', '2026/27', '2027-01-16', '2027-03-06', 'Planeada', 8),
  (12, 'Copa Basquetebol Sub-18', 'Basquetebol', 'Sub-18', '2026/27', '2027-02-20', '2027-04-03', 'Planeada', 3),
  (13, 'Torneio de Natal de Futsal', 'Futsal', 'Seniores', '2026/27', '2026-12-12', '2026-12-20', 'Planeada', 4),
  (14, 'Liga Inter-Escolas de Voleibol', 'Voleibol', 'Sub-17', '2026/27', '2027-03-13', '2027-05-08', 'Planeada', 5),
  (15, 'Campeonato de Futebol de Rua', 'Futebol de Rua', 'Sub-20', '2026/27', '2027-01-23', '2027-03-13', 'Planeada', 6),
  (16, 'Taça da Associação Desportiva da Matola', 'Futebol 11', 'Seniores', '2026/27', '2027-04-10', '2027-06-05', 'Planeada', 7),
  (17, 'Torneio de Páscoa de Futsal Feminino', 'Futsal', 'Feminino', '2026/27', '2027-03-27', '2027-04-17', 'Planeada', 8),
  (18, 'Torneio de Basquetebol 3x3', 'Basquetebol 3x3', 'Seniores', '2026/27', '2027-05-01', '2027-05-22', 'Planeada', 3),
  (19, 'Copa Independência de Futebol', 'Futebol 11', 'Sub-20', '2026/27', '2027-06-05', '2027-06-25', 'Planeada', 4),
  (20, 'Taça de Encerramento da Época', 'Futebol 11', 'Seniores', '2026/27', '2027-07-03', '2027-07-31', 'Planeada', 5);

-- 2.7 Inscricao (20 registos; depende de Competicao e Equipa)
INSERT INTO Inscricao (id_competicao, id_equipa, data_inscricao) VALUES
  (1, 1, '2026-09-02'),
  (1, 2, '2026-09-03'),
  (1, 3, '2026-09-04'),
  (1, 4, '2026-09-05'),
  (1, 5, '2026-09-06'),
  (1, 6, '2026-09-07'),
  (2, 7, '2026-09-08'),
  (2, 8, '2026-09-09'),
  (2, 9, '2026-09-10'),
  (2, 10, '2026-09-11'),
  (2, 11, '2026-09-12'),
  (2, 12, '2026-09-13'),
  (3, 13, '2026-09-14'),
  (3, 14, '2026-09-15'),
  (3, 15, '2026-09-16'),
  (3, 16, '2026-09-17'),
  (4, 17, '2026-09-18'),
  (4, 18, '2026-09-19'),
  (4, 19, '2026-09-20'),
  (4, 20, '2026-09-01');

-- 2.8 Jornada (20 registos; entidade fraca, depende de Competicao)
INSERT INTO Jornada (id_competicao, numero_jornada, data_jornada, descricao) VALUES
  (1, 1, '2026-10-03', '1.ª Jornada'),
  (1, 2, '2026-10-10', '2.ª Jornada'),
  (1, 3, '2026-10-24', '3.ª Jornada'),
  (1, 4, '2026-10-31', '4.ª Jornada'),
  (1, 5, '2026-11-07', '5.ª Jornada'),
  (2, 1, '2026-10-04', '1.ª Jornada'),
  (2, 2, '2026-10-11', '2.ª Jornada'),
  (2, 3, '2026-10-25', '3.ª Jornada'),
  (2, 4, '2026-11-01', '4.ª Jornada'),
  (2, 5, '2026-11-08', '5.ª Jornada'),
  (3, 1, '2026-10-07', '1.ª Jornada'),
  (3, 2, '2026-10-14', '2.ª Jornada'),
  (3, 3, '2026-10-21', '3.ª Jornada'),
  (4, 1, '2026-10-10', '1.ª Jornada'),
  (4, 2, '2026-10-17', '2.ª Jornada'),
  (4, 3, '2026-10-31', '3.ª Jornada'),
  (5, 1, '2026-12-05', '1.ª Jornada'),
  (5, 2, '2026-12-12', '2.ª Jornada'),
  (5, 3, '2026-12-19', '3.ª Jornada'),
  (5, 4, '2026-12-20', 'Final');

-- 2.9 Jogo (23 registos; depende de Jornada, Inscricao e Arbitro)
INSERT INTO Jogo (id_jogo, id_competicao, numero_jornada, id_equipa_casa, id_equipa_fora, id_arbitro, data_hora, local_jogo, estado) VALUES
  (1, 1, 1, 1, 2, 1, '2026-10-03 15:00:00', 'Campo do Malhangalene', 'Realizado'),
  (2, 1, 1, 3, 4, 2, '2026-10-03 16:30:00', 'Campo do Maxaquene', 'Realizado'),
  (3, 1, 1, 5, 6, 3, '2026-10-03 15:00:00', 'Campo da Mafalala', 'Realizado'),
  (4, 1, 2, 1, 3, 4, '2026-10-10 15:00:00', 'Campo do Malhangalene', 'Realizado'),
  (5, 1, 2, 2, 5, 5, '2026-10-10 16:30:00', 'Campo da Polana Caniço', 'Realizado'),
  (6, 1, 2, 4, 6, 6, '2026-10-10 15:00:00', 'Campo do Xipamanine', 'Realizado'),
  (7, 2, 1, 7, 8, 7, '2026-10-04 10:00:00', 'Pavilhão do Alto-Maé', 'Realizado'),
  (8, 2, 1, 9, 10, 8, '2026-10-04 11:30:00', 'Pavilhão de Laulane', 'Realizado'),
  (9, 2, 1, 11, 12, 9, '2026-10-04 10:00:00', 'Pavilhão de Magoanine', 'Realizado'),
  (10, 2, 2, 7, 9, 10, '2026-10-11 10:00:00', 'Pavilhão do Alto-Maé', 'Realizado'),
  (11, 2, 2, 8, 11, 11, '2026-10-11 11:30:00', 'Pavilhão de Hulene', 'Realizado'),
  (12, 2, 2, 10, 12, 12, '2026-10-11 10:00:00', 'Pavilhão do Zimpeto', 'Realizado'),
  (13, 3, 1, 13, 14, 13, '2026-10-07 14:00:00', 'Campo da Escola de Laulane', 'Realizado'),
  (14, 3, 1, 15, 16, 14, '2026-10-07 14:00:00', 'Campo da Escola do Zimpeto', 'Realizado'),
  (15, 3, 2, 13, 15, 15, '2026-10-14 14:00:00', 'Campo da Escola de Laulane', 'Realizado'),
  (16, 3, 2, 14, 16, 16, '2026-10-14 14:00:00', 'Campo da Escola da Polana', 'Realizado'),
  (17, 4, 1, 17, 18, 17, '2026-10-10 17:00:00', 'Pavilhão da Costa do Sol', 'Realizado'),
  (18, 4, 1, 19, 20, 18, '2026-10-10 18:30:00', 'Pavilhão do Jardim', 'Realizado'),
  (19, 4, 2, 17, 19, 19, '2026-10-17 17:00:00', 'Pavilhão da Costa do Sol', 'Realizado'),
  (20, 4, 2, 18, 20, 20, '2026-10-17 18:30:00', 'Pavilhão de Sommerschield', 'Realizado'),
  (21, 1, 3, 1, 4, 1, '2026-10-24 15:00:00', 'Campo do Malhangalene', 'Agendado'),
  (22, 1, 3, 2, 6, 2, '2026-10-24 16:30:00', 'Campo da Polana Caniço', 'Agendado'),
  (23, 1, 3, 3, 5, 3, '2026-10-24 15:00:00', 'Campo do Maxaquene', 'Agendado');

-- 2.10 Resultado (20 registos; só existe para jogos realizados)
INSERT INTO Resultado (id_resultado, id_jogo, golos_casa, golos_fora, data_registo, observacoes) VALUES
  (1, 1, 2, 1, '2026-10-03 20:30:00', NULL),
  (2, 2, 0, 0, '2026-10-03 20:30:00', 'Jogo equilibrado, sem golos'),
  (3, 3, 3, 2, '2026-10-03 20:30:00', NULL),
  (4, 4, 1, 1, '2026-10-10 20:30:00', NULL),
  (5, 5, 2, 0, '2026-10-10 20:30:00', NULL),
  (6, 6, 1, 3, '2026-10-10 20:30:00', 'Vitória clara do visitante'),
  (7, 7, 5, 3, '2026-10-04 20:30:00', NULL),
  (8, 8, 2, 2, '2026-10-04 20:30:00', NULL),
  (9, 9, 4, 1, '2026-10-04 20:30:00', NULL),
  (10, 10, 3, 1, '2026-10-11 20:30:00', NULL),
  (11, 11, 6, 2, '2026-10-11 20:30:00', 'Maior goleada da jornada'),
  (12, 12, 3, 3, '2026-10-11 20:30:00', NULL),
  (13, 13, 2, 0, '2026-10-07 20:30:00', NULL),
  (14, 14, 1, 1, '2026-10-07 20:30:00', NULL),
  (15, 15, 3, 1, '2026-10-14 20:30:00', NULL),
  (16, 16, 0, 2, '2026-10-14 20:30:00', NULL),
  (17, 17, 62, 55, '2026-10-10 20:30:00', 'Jogo decidido no último período'),
  (18, 18, 48, 51, '2026-10-10 20:30:00', NULL),
  (19, 19, 70, 64, '2026-10-17 20:30:00', NULL),
  (20, 20, 66, 60, '2026-10-17 20:30:00', 'Vitória tranquila do visitante');

-- =====================================================================
-- PARTE 3 — VISTA DE CLASSIFICAÇÃO (calculada a partir dos resultados)
-- Vitória = 3 pontos, empate = 1 ponto, derrota = 0 pontos.
-- =====================================================================
CREATE VIEW vw_classificacao AS
SELECT i.id_competicao,
       e.id_equipa,
       e.nome AS equipa,
       COUNT(r.id_resultado) AS jogos,
       COALESCE(SUM(CASE WHEN (j.id_equipa_casa = e.id_equipa AND r.golos_casa > r.golos_fora)
                           OR (j.id_equipa_fora = e.id_equipa AND r.golos_fora > r.golos_casa) THEN 1 ELSE 0 END), 0) AS vitorias,
       COALESCE(SUM(CASE WHEN r.golos_casa = r.golos_fora THEN 1 ELSE 0 END), 0) AS empates,
       COALESCE(SUM(CASE WHEN (j.id_equipa_casa = e.id_equipa AND r.golos_casa < r.golos_fora)
                           OR (j.id_equipa_fora = e.id_equipa AND r.golos_fora < r.golos_casa) THEN 1 ELSE 0 END), 0) AS derrotas,
       COALESCE(SUM(CASE WHEN j.id_equipa_casa = e.id_equipa THEN r.golos_casa
                         WHEN j.id_equipa_fora = e.id_equipa THEN r.golos_fora ELSE 0 END), 0) AS golos_marcados,
       COALESCE(SUM(CASE WHEN j.id_equipa_casa = e.id_equipa THEN r.golos_fora
                         WHEN j.id_equipa_fora = e.id_equipa THEN r.golos_casa ELSE 0 END), 0) AS golos_sofridos,
       COALESCE(SUM(CASE WHEN j.id_equipa_casa = e.id_equipa THEN r.golos_casa - r.golos_fora
                         WHEN j.id_equipa_fora = e.id_equipa THEN r.golos_fora - r.golos_casa ELSE 0 END), 0) AS diferenca_golos,
       COALESCE(SUM(CASE WHEN (j.id_equipa_casa = e.id_equipa AND r.golos_casa > r.golos_fora)
                           OR (j.id_equipa_fora = e.id_equipa AND r.golos_fora > r.golos_casa) THEN 3
                         WHEN r.golos_casa = r.golos_fora THEN 1 ELSE 0 END), 0) AS pontos
FROM Inscricao i
JOIN Equipa e ON e.id_equipa = i.id_equipa
LEFT JOIN Jogo j ON j.id_competicao = i.id_competicao
                AND (j.id_equipa_casa = e.id_equipa OR j.id_equipa_fora = e.id_equipa)
LEFT JOIN Resultado r ON r.id_jogo = j.id_jogo
GROUP BY i.id_competicao, e.id_equipa, e.nome;

-- Verificação rápida do número de registos de cada tabela
SELECT 'Utilizador' AS tabela, COUNT(*) AS total FROM Utilizador
UNION ALL SELECT 'Treinador', COUNT(*) FROM Treinador
UNION ALL SELECT 'Arbitro', COUNT(*) FROM Arbitro
UNION ALL SELECT 'Equipa', COUNT(*) FROM Equipa
UNION ALL SELECT 'Jogador', COUNT(*) FROM Jogador
UNION ALL SELECT 'Competicao', COUNT(*) FROM Competicao
UNION ALL SELECT 'Inscricao', COUNT(*) FROM Inscricao
UNION ALL SELECT 'Jornada', COUNT(*) FROM Jornada
UNION ALL SELECT 'Jogo', COUNT(*) FROM Jogo
UNION ALL SELECT 'Resultado', COUNT(*) FROM Resultado;
