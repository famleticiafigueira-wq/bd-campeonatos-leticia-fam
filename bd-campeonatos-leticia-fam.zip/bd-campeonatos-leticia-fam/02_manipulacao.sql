-- =====================================================================
-- Projeto de Base de Dados — Sistema de Gestão de Campeonatos Desportivos Comunitários
-- Autora: Letícia Figueira Fam
-- Ficheiro: 02_manipulacao.sql
-- Conteúdo: comandos de manipulação de dados (SELECT, JOIN, UPDATE, DELETE e teste de integridade).
-- Pré-requisito: executar primeiro 01_criacao_e_insercao.sql.
-- Para cada comando está indicado o RESULTADO ESPERADO antes da execução.
-- =====================================================================

USE campeonatos_comunitarios;

-- =====================================================================
-- A) SELECT SIMPLES (3) — com filtro (WHERE) e ordenação (ORDER BY)
-- =====================================================================

-- A1. Guarda-redes registados, por ordem alfabética.
-- ESPERADO: 7 linhas (Alberto Come, Carlos Matsinhe, Hermínia Sumbana, Ivan Chirindza,
--           Manuel Uqueio, Pedro Mavie, Valdemiro Manjate), todos com posição 'Guarda-Redes'.
SELECT nome, posicao, numero_camisola
FROM Jogador
WHERE posicao = 'Guarda-Redes'
ORDER BY nome ASC;

-- A2. Competições de futsal que ainda estão planeadas, da mais próxima para a mais distante.
-- ESPERADO: 3 linhas — Torneio de Natal de Futsal (2026-12-12), Torneio de Futsal Sub-15 (2027-02-06)
--           e Torneio de Páscoa de Futsal Feminino (2027-03-27), por esta ordem.
SELECT nome, categoria, data_inicio, data_fim
FROM Competicao
WHERE modalidade = 'Futsal' AND estado = 'Planeada'
ORDER BY data_inicio ASC;

-- A3. Jogos ainda agendados (sem resultado), por data e hora.
-- ESPERADO: 3 linhas, todas da 3.ª jornada da Taça dos Bairros, a 2026-10-24: jogos 21 e 23 (15:00) e jogo 22 (16:30).
SELECT id_jogo, data_hora, local_jogo, estado
FROM Jogo
WHERE estado = 'Agendado'
ORDER BY data_hora ASC, id_jogo ASC;

-- =====================================================================
-- B) SELECT COM JOIN (2) — juntar várias tabelas para mostrar informação completa
-- =====================================================================

-- B1. Calendário e resultados da Taça dos Bairros 2026 (jogos realizados), com equipas, árbitro e resultado.
-- ESPERADO: 6 linhas (jogos 1 a 6), por data. A primeira: Malhangalene FC 2 - 1 Polana Caniço United,
--           árbitro Albino Chaúque, a 2026-10-03.
SELECT c.nome  AS competicao,
       j.numero_jornada AS jornada,
       j.data_hora,
       ec.nome AS equipa_casa,
       r.golos_casa,
       r.golos_fora,
       ef.nome AS equipa_visitante,
       a.nome  AS arbitro
FROM Jogo j
JOIN Competicao c ON c.id_competicao = j.id_competicao
JOIN Equipa ec    ON ec.id_equipa   = j.id_equipa_casa
JOIN Equipa ef    ON ef.id_equipa   = j.id_equipa_fora
JOIN Arbitro a    ON a.id_arbitro   = j.id_arbitro
JOIN Resultado r  ON r.id_jogo      = j.id_jogo
WHERE c.id_competicao = 1
ORDER BY j.data_hora, j.id_jogo;

-- B2. Jogos de futsal com mais de 4 golos no total, com o nome do treinador da equipa da casa.
-- ESPERADO: 4 linhas, por ordem de total de golos: jogo 7 (Alto-Maé FC 5-3 Hulene Unidos, 8 golos),
--           jogo 11 (Hulene Unidos 6-2 Magoanine Leões, 8), jogo 12 (Zimpeto Águias 3-3 Albasine Rangers, 6)
--           e jogo 9 (Magoanine Leões 4-1 Albasine Rangers, 5).
SELECT j.id_jogo,
       ec.nome AS equipa_casa,
       t.nome  AS treinador_casa,
       r.golos_casa,
       r.golos_fora,
       ef.nome AS equipa_visitante,
       (r.golos_casa + r.golos_fora) AS total_golos
FROM Jogo j
JOIN Competicao c ON c.id_competicao = j.id_competicao
JOIN Equipa ec    ON ec.id_equipa    = j.id_equipa_casa
JOIN Treinador t  ON t.id_treinador  = ec.id_treinador
JOIN Equipa ef    ON ef.id_equipa    = j.id_equipa_fora
JOIN Resultado r  ON r.id_jogo       = j.id_jogo
WHERE c.modalidade = 'Futsal'
  AND (r.golos_casa + r.golos_fora) > 4
ORDER BY total_golos DESC, j.id_jogo;

-- B3 (extra). Classificação da Taça dos Bairros 2026 através da vista vw_classificacao.
-- ESPERADO: 6 equipas; lidera o Malhangalene FC com 4 pontos (1 vitória, 1 empate, 2 jogos),
--           e fecha o Xipamanine Estrela com 1 ponto.
SELECT equipa, jogos, vitorias, empates, derrotas,
       golos_marcados, golos_sofridos, diferenca_golos, pontos
FROM vw_classificacao
WHERE id_competicao = 1
ORDER BY pontos DESC, diferenca_golos DESC, golos_marcados DESC;

-- =====================================================================
-- C) UPDATE (2)
-- =====================================================================

-- C1. Atualizar o telefone do treinador 1 (Armando Tivane).
-- ESPERADO: "1 row(s) affected" e o telefone passa a +258 84 555 0101.
UPDATE Treinador
SET telefone = '+258 84 555 0101'
WHERE id_treinador = 1;

SELECT id_treinador, nome, telefone FROM Treinador WHERE id_treinador = 1;

-- C2. Corrigir o resultado do jogo 2 (Maxaquene Juniors x Xipamanine Estrela) de 0-0 para 1-0,
--     após validação da ficha de jogo.
-- ESPERADO: "1 row(s) affected"; o Maxaquene Juniors passa a ter 4 pontos na classificação
--           (1 vitória e 1 empate) e o Xipamanine Estrela desce para 0 pontos.
UPDATE Resultado
SET golos_casa = 1,
    observacoes = 'Resultado corrigido após validação da ficha de jogo'
WHERE id_jogo = 2;

SELECT id_jogo, golos_casa, golos_fora, observacoes FROM Resultado WHERE id_jogo = 2;

-- Confirmação do efeito na classificação:
SELECT equipa, jogos, pontos
FROM vw_classificacao
WHERE id_competicao = 1
ORDER BY pontos DESC, diferenca_golos DESC, golos_marcados DESC;

-- =====================================================================
-- D) DELETE (1) — respeitando as chaves estrangeiras
-- =====================================================================

-- D1. Eliminar o jogo 23 (Maxaquene Juniors x Mafalala Stars), cancelado pela organização.
-- Respeita as chaves estrangeiras porque o jogo 23 ainda não tem Resultado (nenhuma linha filha o referencia).
-- (Não seria possível eliminar, por exemplo, o jogo 1: tem um Resultado associado e o SGBD recusaria
--  o comando com o erro 1451 — para o apagar, teria de se eliminar primeiro o Resultado.)
-- ESPERADO: "1 row(s) affected"; o total de jogos passa de 23 para 22.
SELECT COUNT(*) AS jogos_antes FROM Jogo;

DELETE FROM Jogo
WHERE id_jogo = 23;

SELECT COUNT(*) AS jogos_depois FROM Jogo;

-- =====================================================================
-- E) TESTE DE INTEGRIDADE (1) — chave estrangeira inexistente
-- =====================================================================

-- E1. Tentar inserir um jogador numa equipa que não existe (id_equipa = 99).
-- ESPERADO: o comando FALHA. O SGBD devolve
--   Error Code: 1452. Cannot add or update a child row: a foreign key constraint fails
--   (`campeonatos_comunitarios`.`jogador`, CONSTRAINT `fk_jogador_equipa`
--    FOREIGN KEY (`id_equipa`) REFERENCES `equipa` (`id_equipa`))
-- EXPLICAÇÃO: a coluna Jogador.id_equipa é chave estrangeira de Equipa.id_equipa; como não existe
--   nenhuma equipa com id 99, a inserção deixaria um registo "órfão". A integridade referencial
--   impede-o, garantindo que todo o jogador pertence a uma equipa real.
-- NOTA: este erro é intencional e, por isso, este é o último comando do ficheiro.
INSERT INTO Jogador (nome, data_nascimento, posicao, numero_camisola, id_equipa)
VALUES ('Teste Inexistente', '2001-01-01', 'Médio', 7, 99);
