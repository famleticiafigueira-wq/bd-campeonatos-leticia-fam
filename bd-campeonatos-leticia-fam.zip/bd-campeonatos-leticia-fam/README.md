# bd-campeonatos-leticia-fam

**Sistema de Gestão de Campeonatos Desportivos Comunitários**

| | |
|---|---|
| **Nome** | Letícia Figueira Fam |
| **Curso / Ano** | Licenciatura em Informática — 2.º ano |
| **Disciplina** | Tecnologias de Base de Dados |
| **Tema** | Gestão de campeonatos desportivos comunitários (torneios de bairros, escolas e associações desportivas) |
| **SGBD** | MySQL 8.0.16 ou superior |
| **Vídeo** | 🎥 *(colar aqui o link do YouTube)* |

## 1. Descrição do problema

Em muitos bairros, escolas e associações desportivas, os campeonatos e torneios são organizados de forma informal: as inscrições das equipas ficam em cadernos, o calendário de jogos circula por mensagens, os resultados perdem-se e a classificação é calculada à mão, o que gera dúvidas e discussões entre equipas.

Este projeto propõe uma base de dados para informatizar essa gestão. Cada **equipa** pertence a um bairro ou escola, tem um **treinador** responsável e um plantel de **jogadores**. Uma associação ou organizador cria **competições** (por modalidade, categoria e época, por exemplo futebol, futsal ou basquetebol) e as equipas inscrevem-se nelas. Cada competição é dividida em **jornadas** numeradas, que só fazem sentido dentro dessa competição. Em cada jornada realizam-se **jogos** entre duas equipas inscritas (uma da casa e outra visitante), dirigidos por um **árbitro** e com data, hora e local definidos. Depois de cada jogo realizado, regista-se o **resultado**, e a **classificação** é calculada automaticamente com base nos resultados (vitória 3 pontos, empate 1 ponto, derrota 0).

Existem também **utilizadores** (administradores, organizadores, treinadores, árbitros e adeptos), que serão quem acede ao futuro sistema web. A base de dados contém 10 tabelas, cada uma com pelo menos 20 registos coerentes e realistas, inspirados em bairros de Maputo e Matola.

## 2. Regras de negócio

1. Cada equipa tem exatamente um treinador responsável; um treinador pode orientar várias equipas (por exemplo, escalões diferentes).
2. O nome da equipa é único.
3. Um jogador pertence a uma única equipa, e o número de camisola é único dentro da equipa.
4. Uma equipa pode participar em várias competições e uma competição tem várias equipas; a equipa só pode ser inscrita uma vez em cada competição, e a inscrição regista a data.
5. Cada competição tem uma modalidade, categoria, época, datas de início e fim (o fim nunca é anterior ao início) e é organizada por um utilizador.
6. O estado de uma competição é *Planeada*, *Em curso* ou *Concluída*.
7. A jornada é uma **entidade fraca**: só existe dentro de uma competição e é identificada pela competição e pelo seu número.
8. Cada jogo pertence a uma jornada de uma competição e opõe duas equipas diferentes, ambas inscritas nessa competição: uma joga em casa e outra como visitante.
9. O mesmo confronto (mesma casa e mesmo visitante) não se repete na mesma competição.
10. Cada jogo tem um árbitro e um estado: *Agendado*, *Realizado* ou *Adiado*.
11. Um jogo tem no máximo um resultado, que é registado apenas depois de o jogo se realizar, e os golos (ou pontos) nunca são negativos.
12. A classificação é calculada a partir dos resultados: vitória = 3 pontos, empate = 1, derrota = 0; o desempate faz-se pela diferença de golos e depois pelos golos marcados.
13. O email de cada utilizador é único e o perfil é Administrador, Organizador, Treinador, Árbitro ou Adepto.
14. Não é possível eliminar um registo que seja referenciado por outro (integridade referencial).

## 3. Sistema web previsto (Programação Web)

A mesma base de dados será usada no sistema web do projeto de Programação Web, um portal de campeonatos comunitários com os seguintes utilizadores e funcionalidades:

- **Administrador / Organizador:** autenticação; **registar** equipas, jogadores, treinadores, árbitros, competições, jornadas e jogos através de formulários; **alterar** dados e resultados; **eliminar** registos.
- **Treinador:** gerir o plantel da sua equipa e inscrevê-la em competições.
- **Árbitro:** consultar os jogos que lhe foram atribuídos.
- **Adepto / visitante:** **listar** equipas, calendário de jogos e resultados; **pesquisar** por equipa, bairro, modalidade ou competição; consultar a **classificação** atualizada de cada competição.

## 4. Estrutura do repositório

```
bd-campeonatos-leticia-fam/
 README.md
 diagrama_er.png
 modelo_relacional.md
 01_criacao_e_insercao.sql
 02_manipulacao.sql
```

## 5. Como executar

1. Abrir o MySQL Workbench (ou outra ferramenta MySQL 8.0.16+).
2. Executar `01_criacao_e_insercao.sql` de uma só vez: cria a base de dados `campeonatos_comunitarios`, as tabelas, os registos e a vista `vw_classificacao`.
3. Executar `02_manipulacao.sql`, comando a comando, comparando o resultado obtido com o **ESPERADO** indicado em comentário. O último comando falha de propósito (teste de integridade referencial).

## 6. Diagrama ER

![Diagrama ER](diagrama_er.png)
