# Roteiro do vídeo (8 a 12 minutos) — guião de apoio, não faz parte do repositório

Grava com a tua voz e partilha de ecrã. Antes de cada comando, diz o que esperas; depois executa e compara.

## 1. Apresentação (1 min)
- «Olá, sou a Letícia Figueira Fam, do 2.º ano de Informática. O meu tema é a **Gestão de Campeonatos Desportivos Comunitários**.»
- Porquê: torneios de bairros e escolas são geridos em cadernos e mensagens, e a classificação gera discussões.
- Sistema web previsto: portal onde organizadores registam equipas, jogos e resultados, e os adeptos consultam calendário, pesquisas e classificação.

## 2. Processo de conceção (2–3 min)
- Comecei pelos **nomes** do problema: equipa, jogador, treinador, competição, jornada, jogo, árbitro, resultado, mais utilizador (para o login do sistema web).
- Regras que determinaram as relações: uma equipa tem um treinador; um jogador pertence a uma equipa; uma equipa pode estar em várias competições (N:M, daí a tabela **Inscricao**); um jogo opõe duas equipas inscritas; um jogo tem no máximo um resultado.
- Atributos: o que preciso de mostrar nas listagens e pesquisas do site (bairro, modalidade, categoria, estado, data/hora).
- Mostra 3 ou 4 regras de negócio do README.

## 3. Diagramas (2 min)
- Abre `diagrama_er.png`. Explica **1:N** (Treinador–Equipa, Equipa–Jogador, Arbitro–Jogo), **N:M** (Equipa–Competicao) e **1:1** (Jogo–Resultado).
- **Participação:** linha dupla = total (ex.: toda a equipa tem treinador), simples = parcial (ex.: um jogo ainda sem resultado).
- **Entidade fraca: Jornada.** Só existe dentro de uma competição; a chave é composta (id_competicao + numero_jornada).
- Abre `modelo_relacional.md`: mostra as chaves primárias e estrangeiras, e as FK compostas do Jogo para Inscricao (garantem que as equipas estão inscritas na competição).

## 4. Criação da base de dados (2 min)
- No Workbench, executa `01_criacao_e_insercao.sql`.
- Mostra, no painel Schemas, as 10 tabelas e abre algumas com «Select Rows». Mostra o resultado final da contagem (20, 20, 20, 20, 40, 20, 20, 20, 23, 20).

## 5. Execução dos comandos (3–4 min) — diz o ESPERADO que está nos comentários do ficheiro
| Comando | O que dizer antes de executar |
|---|---|
| A1 | «Espero 7 guarda-redes por ordem alfabética.» |
| A2 | «Espero 3 competições de futsal planeadas, da mais próxima à mais distante.» |
| A3 | «Espero 3 jogos agendados, todos a 24 de outubro.» |
| B1 | «Espero 6 jogos da Taça dos Bairros, com equipas, resultado e árbitro. O primeiro é Malhangalene 2-1 Polana Caniço.» |
| B2 | «Espero 4 jogos de futsal com mais de 4 golos; os dois primeiros com 8 golos.» |
| B3 (extra) | «Espero o Malhangalene líder com 4 pontos.» |
| C1 | «Espero 1 linha afetada; o telefone passa a +258 84 555 0101.» |
| C2 | «Espero 1 linha afetada; o Maxaquene sobe para 4 pontos e o Xipamanine desce para 0.» |
| D1 | «Espero apagar o jogo 23 porque não tem resultado associado; o total passa de 23 para 22. O jogo 1 não se poderia apagar: tem Resultado.» |
| E1 | «Espero um erro 1452: não existe a equipa 99.» Explica: a FK impede registos órfãos. |

## 6. Conclusão (1 min)
- Dificuldades: modelar a entidade fraca e as FK compostas, e calcular a classificação sem a guardar (vista).
- Aprendizagem: a integridade referencial protege os dados.
- Melhorias: tabela de golos por jogador, fases eliminatórias, histórico de épocas.
